# Capai Camera — versi baru

Fitur awal:
- Kamera belakang
- ISO: Auto / 100 / 200 / 400 / 800 / 1600 / 3200 (dibatasi kemampuan sensor)
- Autofokus: Auto / Continuous
- Tombol foto
- Struktur siap dibuild melalui GitHub Actions

## Build hanya dari HP
1. Buat repository baru di GitHub, misalnya `CapaiCamera`.
2. Upload semua isi folder proyek ini ke repository.
3. Pastikan folder `.github/workflows/build.yml` ikut ter-upload.
4. Buka tab **Actions** → workflow **Build APK** → **Run workflow**.
5. Setelah selesai, buka hasil run → **Artifacts** → `CapaiCamera-debug`.
6. Download ZIP artifact, ekstrak, lalu instal `app-debug.apk`.

Catatan:
- ISO manual hanya bekerja jika sensor kamera HP mendukung pengaturan SENSOR_SENSITIVITY.
- Beberapa HP akan mengabaikan nilai ISO tertentu atau memilih nilai terdekat.
- Versi berikutnya dapat menambahkan shutter speed, EV, kamera depan, zoom, grid, flash, dan penyimpanan foto MediaStore yang lebih lengkap.
