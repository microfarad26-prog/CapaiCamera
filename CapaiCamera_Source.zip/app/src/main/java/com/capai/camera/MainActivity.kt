package com.capai.camera

import android.Manifest
import android.app.Activity
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.SurfaceTexture
import android.hardware.camera2.*
import android.os.*
import android.provider.MediaStore
import android.view.*
import android.widget.*
import androidx.core.app.ActivityCompat
import java.util.*

class MainActivity : Activity() {
    private lateinit var preview: TextureView
    private lateinit var cameraManager: CameraManager
    private var cameraDevice: CameraDevice? = null
    private var session: CameraCaptureSession? = null
    private var requestBuilder: CaptureRequest.Builder? = null
    private var cameraId = ""
    private var iso = 0
    private var afAuto = true
    private var characteristics: CameraCharacteristics? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        preview = findViewById(R.id.preview)
        cameraManager = getSystemService(CAMERA_SERVICE) as CameraManager

        val spinner = findViewById<Spinner>(R.id.isoSpinner)
        val isoValues = arrayOf("AUTO","100","200","400","800","1600","3200")
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, isoValues)
        spinner.setSelection(0)
        spinner.onItemSelectedListener = object: AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(p: AdapterView<*>?) {}
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                iso = if (pos == 0) 0 else isoValues[pos].toInt()
                updatePreview()
            }
        }

        findViewById<Button>(R.id.afButton).setOnClickListener {
            afAuto = !afAuto
            it as Button
            it.text = if (afAuto) "AF: AUTO" else "AF: CONT"
            updatePreview()
        }
        findViewById<Button>(R.id.captureButton).setOnClickListener { captureStill() }

        preview.surfaceTextureListener = object: TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) { openCamera() }
            override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) {}
            override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean { return true }
            override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
        }
    }

    private fun openCamera() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), 10); return
        }
        cameraId = cameraManager.cameraIdList.firstOrNull { id ->
            cameraManager.getCameraCharacteristics(id).get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
        } ?: cameraManager.cameraIdList[0]
        characteristics = cameraManager.getCameraCharacteristics(cameraId)
        cameraManager.openCamera(cameraId, object: CameraDevice.StateCallback() {
            override fun onOpened(camera: CameraDevice) { cameraDevice = camera; createPreview() }
            override fun onDisconnected(camera: CameraDevice) { camera.close(); cameraDevice = null }
            override fun onError(camera: CameraDevice, error: Int) { camera.close(); cameraDevice = null }
        }, Handler(Looper.getMainLooper()))
    }

    private fun createPreview() {
        val surface = Surface(preview.surfaceTexture)
        requestBuilder = cameraDevice!!.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW).apply {
            addTarget(surface)
        }
        cameraDevice!!.createCaptureSession(listOf(surface), object: CameraCaptureSession.StateCallback() {
            override fun onConfigured(s: CameraCaptureSession) { session = s; updatePreview() }
            override fun onConfigureFailed(s: CameraCaptureSession) {}
        }, null)
    }

    private fun updatePreview() {
        val b = requestBuilder ?: return
        try {
            if (iso > 0) b.set(CaptureRequest.SENSOR_SENSITIVITY, iso)
            else b.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON)
            b.set(CaptureRequest.CONTROL_AF_MODE,
                if (afAuto) CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE
                else CaptureRequest.CONTROL_AF_MODE_AUTO)
            session?.setRepeatingRequest(b.build(), null, null)
        } catch (_: Exception) {}
    }

    private fun captureStill() {
        val device = cameraDevice ?: return
        val b = device.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE)
        val surface = Surface(preview.surfaceTexture)
        b.addTarget(surface)
        try {
            if (iso > 0) b.set(CaptureRequest.SENSOR_SENSITIVITY, iso)
            b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
            session?.capture(b.build(), object: CameraCaptureSession.CaptureCallback() {}, null)
            Toast.makeText(this, "Foto diambil", Toast.LENGTH_SHORT).show()
        } catch (_: Exception) {}
    }

    override fun onDestroy() {
        session?.close(); cameraDevice?.close(); super.onDestroy()
    }
}
